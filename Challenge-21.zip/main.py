class BankAccount
def__init__(self, account_number, account_holder_name,initial_balance=0.0):
  self._account_number=account _number
  self._account_holder_name=account _holder_name
  self._account_balance=initial_balance
def deposit (self, amount ):
  if amount>0:
    self._account_balance+= amount
    print (" Deposited ₹{}. New balance.₹{}".format( amount,self._account_balance))
  else:
    print(" Invalid deposit amount.please deposit a positive amount.")
  def withdraw ( self, amount ):
    if amount>0 and amount<= self._ account _ balance
    self._ account_ balance= amount
    print ("withdraw ₹{}. New balance {}.formate(amount,self._account balance ")
    else
       print("Invalid with drawal amount or insufficient balance")
  def display_ balance (self ):
     print(" Account balance for {} {} (Account #{}:₹{}". format(
       self._ account_ bolder_ name,self._account_number,
       self._account_balance))
# create an instant of the BankAccount class
account= BankAccount( account_number="12345678") account _holder_nam='Divya',
initial_balance=5000.0)
#Test deposit and withdraw functionality
account display_balance()
account.deposit(5000.0)
account.withdraw(200.0)
account display_balance()
    
    
  